interface Print_Board {
    void PrintBoard(int[][] pieces) throws Exception;
}
