public class Play_BoardGames {
    public static void main(String[] args) throws Exception{
        System.out.println("Welcome to BoardGames!!!");
        Menu menu_first = new Menu();
        menu_first.MainMenu();
        System.out.println("\nSee you next time!!!");
    }
}