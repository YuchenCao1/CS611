interface Get_Board_Size {
    int Get_Boardsize() throws Exception;
}
